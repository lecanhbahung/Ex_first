package BinaryTree;

public class Node {
    int value;
    Node left,right;

    public Node(int item) {
        this.value = item;
        left=right=null;
    }
}
